package com.example.hi.content;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;

public class MyContentProvider extends ContentProvider {
    DbHelper dbHelper;
    public static final String authority="com.example.hi.content.provider";
    public static final int task=100;
    public static final int taskWithId=101;
    public static final Uri Base_uri=Uri.parse("content://"+authority);
    public static final String path=DbHelper.Table_name;
    public static final Uri content_uri=Base_uri.buildUpon().appendPath(path).build();
    public static final UriMatcher uriMatcher=buildUriMatcher();

    private static UriMatcher buildUriMatcher() {

        UriMatcher matcher=new UriMatcher(UriMatcher.NO_MATCH);
        matcher.addURI(authority,path,task);
        matcher.addURI(authority,path+"/#",taskWithId);
        return matcher;
    }


    public MyContentProvider() {
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // Implement this to handle requests to delete one or more rows.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public String getType(Uri uri) {
        // TODO: Implement this to handle requests for the MIME type of the data
        // at the given URI.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // TODO: Implement this to handle requests to insert a new row.
        SQLiteDatabase sqLiteDatabase=dbHelper.getWritableDatabase();

        Uri returnUri=null;
        switch (uriMatcher.match(uri)){
            case task:
                long myid=sqLiteDatabase.insert(DbHelper.Table_name,null,values);
                if (myid>0){
                    returnUri= ContentUris.withAppendedId(uri,myid);
                }
                break;
        }

         return returnUri;
    }

    @Override
    public boolean onCreate() {
        // TODO: Implement this to initialize your content provider on startup.
        dbHelper=new DbHelper(getContext());
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        // TODO: Implement this to handle query requests from clients.
        SQLiteDatabase sqLiteDatabase=dbHelper.getReadableDatabase();
       //throw new UnsupportedOperationException("Not yet implemented");
        return sqLiteDatabase.rawQuery("select  *  from  "+ DbHelper.Table_name,null);
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        // TODO: Implement this to handle requests to update one or more rows.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
