package com.example.hi.content;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbHelper extends SQLiteOpenHelper {
    public static final String Dbname="it-a";
    public static final String Table_name="Student";
    public  static final String col_0="sno";
    public  static final String col_1="name";
    public static final String query="create table "+Table_name+"("+col_0   +"     integer primary key autoincrement ,"+col_1+"   text not null);";
    public DbHelper(Context context) {
        super(context, Dbname, null, 5);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists "+Table_name);
        onCreate(db);
    }
}
