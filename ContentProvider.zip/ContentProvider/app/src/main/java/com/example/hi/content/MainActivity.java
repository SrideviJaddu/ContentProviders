package com.example.hi.content;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText=(EditText)findViewById(R.id.et);
    }

    public void submit(View view) {
        String myData=editText.getText().toString();
        Toast.makeText(this, myData, Toast.LENGTH_SHORT).show();
        ContentValues contentValues=new ContentValues();
        contentValues.put(DbHelper.col_1,myData);
        Uri uri=getContentResolver().insert(MyContentProvider.content_uri,contentValues);
        if(uri!=null){
            Toast.makeText(this, uri.toString(), Toast.LENGTH_SHORT).show();
        }
        Toast.makeText(this,"inserted",Toast.LENGTH_SHORT).show();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void read(View view) {
        //Toast.makeText(this, "entered here", Toast.LENGTH_SHORT).show();
        Cursor cursor=getContentResolver().query(MyContentProvider.content_uri,null,null,null);
        StringBuilder stringBuilder=new StringBuilder();
        while (cursor.moveToNext()){
            stringBuilder.append(cursor.getInt(0)+"   "+cursor.getString(1)+"\n");
        }
        Toast.makeText(this,stringBuilder.toString(),Toast.LENGTH_LONG).show();
    }
}
